from flask import Flask, render_template, request, flash
import requests
import json
from twilio.rest import Client
from datetime import datetime
import random
from geopy.distance import geodesic
import os
import urllib.request

app = Flask(__name__)
app.secret_key = '1234'

# Twilio configuration
account_sid = os.environ['TWILIO_ACCOUNT_SID']
auth_token = os.environ['TWILIO_AUTH_TOKEN']
twilio_number = '+12568575226'
my_number = '+14372459313'

client = Client(account_sid, auth_token)


def get_random_harry_potter_character():
    response = requests.get('https://hp-api.onrender.com/api/characters')
    if response.status_code == 200:
        characters = response.json()
        random_character = random.choice(characters)
        return random_character['name']
    return 'Harry Potter'


# Defining the function to get weather
def get_weather():
    api_key = '6c5c3f98f4e39e89270007461205888f'
    latitude = 6.543461
    longitude = 3.373178
    weather_url = f'https://api.openweathermap.org/data/2.5/weather?lat={latitude}&lon={longitude}&appid={api_key}&units=metric'
    response = requests.get(weather_url)
    if response.status_code == 200:
        weather_data = response.json()
        return weather_data['weather'][0]['description'], weather_data['main'][
            'temp']
    return 'unknown', 'unknown'


# Defining the function to get number of peoples in space
def get_people_in_space():
    url = 'http://api.open-notify.org/astros.json'
    request = urllib.request.urlopen(url)
    result = json.loads(request.read())
    return result['number']


# Function to log text sent via SMS to a JSON file
def log_message(message):
    log_entry = {'message': message, 'timestamp': datetime.now().isoformat()}
    with open('logs/messages.json', 'a') as log_file:
        json.dump(log_entry, log_file)
        log_file.write('\n')


# Route for the homepage
@app.route('/')
def index():
    return render_template('index.html')


# Route to send the text message
@app.route('/send_message', methods=['POST'])
def send_message():
    character = get_random_harry_potter_character()
    weather_description, temperature = get_weather()
    people_in_space = get_people_in_space()

    message = f"Hello,{character} from the Harry Porter Movie, You're an amazing character and just so you know I am from Lagos and the current weather condition is {weather_description}, at {temperature} °C. Let's share a little secret, I heard there  are {people_in_space} number of people in space!"

    try:
        #Sending the text via Twilio
        client.messages.create(body=message, from_=twilio_number, to=my_number)
        log_message(message)
        flash('Text sent successfully!', 'success')
    except Exception as e:
        flash(f'Failed to send Text: {str(e)}', 'danger')

    return render_template('index.html')


# Run the Flask application
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)
